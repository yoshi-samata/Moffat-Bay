<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="header.css">
    <link rel="stylesheet" href="index.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moffat Bay Marina</title>

</head>

<body>
    <?php include 'header.html'; ?>

    <body>
        <main>

            <div id="title">
                <h1>Moffat Bay Marina</h1>
                <h2>Your Gateway to Fun on the Water</h2>
            </div>

            <div id="overlay">
                <div id="content">

                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>


                    <h1>Romantic getaways</h1>
                    <p>
                        Moffat Bay Marina is a great place to getaway with your special someone. From proposals to
                        50th<br>
                        Aniversaries
                        your special day will be perfect, here at Moffat Bay.
                    </p>

                    <img src="images/romanticprop.webp" id="proposal">

                    <h1>Celibrations</h1>
                    <p>
                        Celibrate Graduations, Birthdays, Family Reunons or Aniversaries.
                    </p>
                    <img src="images/partygirls.webp">

                    <h1>Retire on the Water</h1>
                    <p>
                        Finally retired? Moffatbay provides the perfect atmosphere to enjoy your retirement
                        on the water.
                    </p>
                    <img src="images/finalyRetired.webp">
                </div>
            </div>

        </main>
        <footer>
            <p>&copy; 2025 Your Website. All rights reserved.</p>
        </footer>
    </body>

</html>